public class Encounters {

    enum location{
        physical,

        telemedicine

    }
}
